
import { Component } from "react";
import { connect } from "react-redux"
import { bindActionCreators } from "redux";
import { selectUser } from "../actions/user_action";

class UserList extends Component {

   renderUser(){
    return this.props.userdata.map((user)=>{
        return <li onClick={()=>this.props.su(user)}>
            {user.uname}
        </li>;
    });
   }
    render() {
      
        return (
            <div>
                <p> User List</p>
                <br/>
                <hr/>
                {this.renderUser()}
            </div>
        );
    }
}

function mapStateToProps(state){
    return{
        userdata:state.myuser,
    }
}
function mapDispatchToProps(dispatch){
    return bindActionCreators({su:selectUser},dispatch);
}
export default connect(mapStateToProps,mapDispatchToProps)(UserList);