
import { Component } from "react";
import { connect } from "react-redux"
import { bindActionCreators } from "redux";
import { selectProject } from "../actions/project_action";

class ProjectList extends Component {

   renderProject(){
    return this.props.projectData.map((project)=>{
        return <li onClick={()=>this.props.sp(project)}>
            {project.pname}
        </li>
    })
   }
    render() {
      
        return (
            <div>
                <p> Project List</p>
                <br/>
                <hr/>
                {this.renderProject()}
            </div>
        );
    }
}

function mapStateToProps(state){
    return{
        projectData:state.myProject,
    }
}

function mapDispatchToProps(dispatch){
    return bindActionCreators({sp:selectProject},dispatch);
}
export default connect(mapStateToProps,mapDispatchToProps)(ProjectList);