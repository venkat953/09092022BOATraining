
import { Component } from "react";
import ProjectDetails from "./ProjectDetails";
import ProjectList from "./ProjectList";
import UserDetails from "./UserDetails";
import UserList from "./UserList";


export default class UserApp extends Component {

   
    render() {
      
        return (
            <div>
                <UserList/>
                <hr/>
                <UserDetails/>
                <hr/>
                <ProjectList/>
                <hr/>
                <ProjectDetails/>
                <hr/>
            </div>
        );
    }
}
