
import { Component } from "react";
import { connect } from 'react-redux'

class ProjectDetails extends Component {


    render() {
        if (!this.props.pd) {
            return <div> Select a project to get started</div>
        }
        return (
            <div>
                <h3> Project Details</h3>
                <div> ProjectName:{this.props.pd.pname}</div>
                <div> Location:{this.props.pd.location}</div>
                <div> Budget:{this.props.pd.budget}</div>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        pd: state.activeProject
    }
}
export default connect(mapStateToProps)(ProjectDetails)