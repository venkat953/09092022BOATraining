
import { Component } from "react";
import { connect } from 'react-redux'

class UserDetails extends Component {


    render() {
        if (!this.props.ud) {
            return <div> Select a user to get started</div>
        }
        return (
            <div>
                <h3> User Details</h3>
                <div> UserName:{this.props.ud.uname}</div>
                <div> Email:{this.props.ud.email}</div>
                <div> City:{this.props.ud.city}</div>
            </div>
        );
    }
}

function mapStateToProps(state) {
    return {
        ud: state.ac
    }
}
export default connect(mapStateToProps)(UserDetails)