import React from 'react';
import { useSelector,useDispatch } from 'react-redux'
import { increment, decrement } from '../actions/user_action';
function Counter(props) {
    const data= useSelector((state) => state.counter)
    const dispatch= useDispatch()
    return (
        <div>
            <h3> The Counter is : {data}</h3>
            <button onClick={() => dispatch(increment())}>INCREMENT</button>
            <button onClick={() => dispatch(decrement())}>DECREMENT</button>
        </div>
    );
}

export default Counter;
