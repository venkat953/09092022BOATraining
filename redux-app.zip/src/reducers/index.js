import { combineReducers } from 'redux'
import UserReducer from './reducer_users'
import ProjectReducer from './reducer_projects'
import ActiveUser from './reducer_active_user'
import ActiveProject from './reducer_active_project'
const rootReducer=combineReducers({
    myuser:UserReducer,
    myProject:ProjectReducer,
    ac:ActiveUser,
    activeProject:ActiveProject
})

export default rootReducer