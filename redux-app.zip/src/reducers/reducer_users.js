
export default function(){
    return[
        {uname:"Admin",email:"admin@mail.com",city:"bnglr"},
        {uname:"Manager",email:"admin@mail.com",city:"pune"},
        {uname:"QA",email:"admin@mail.com",city:"chennai"},
        {uname:"Finance",email:"admin@mail.com",city:"hyderabad"},
        
    ]
}