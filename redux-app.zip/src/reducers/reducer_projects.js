
export default function(){
    return[
        {pname:"HRMS",location:"Assam",budget:"1000"},
        {pname:"Banking",location:"Assam",budget:"1000"},
        {pname:"Hospitality",location:"Assam",budget:"1000"},
        {pname:"Finance",location:"Assam",budget:"1000"},
        
    ]
}