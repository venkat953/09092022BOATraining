import logo from './logo.svg';
import './App.css';
import UserApp from './components/UserApp';
import Counter from './counterapp/components/Counter';

function App() {
  return (
    <div className="App">
      <Counter/>
    </div>
  );
}

export default App;
