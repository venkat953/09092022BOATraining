import React from "react";
import { Formik, Form } from "formik";
import TextField from "./TextField";
import * as Yup from "yup";
function SignUp(props) {
    const validate = Yup.object({
        firstName: Yup.string()
            .max(15, "Must be 15 chars or less")
            .required("Required"),
        lastName: Yup.string()
            .max(20, "Must be 20 chars or less")
            .required("Required"),
        email: Yup.string().email("Email is invalid").required("Email is Required"),
        password: Yup.string()
            .max(6, "Password must be 6 chars")
            .required("Password is Required"),
        confirmPassword: Yup.string()
            .oneOf([Yup.ref("password"), null], "Password must match")
            .required("confirm password is Required"),
        city: Yup.string()
            .min(6, "Minimum be 6 chars or less")
            .max(15, "Must be 15 chars or less")
            .required("Required"),
        country: Yup.string()
            .max(15, "Must be 15 chars or less")
            .required("Required"),
        confirmEmail: Yup.string()
            .oneOf([Yup.ref("email"), null], "Email must match")
            .required("confirm email is Required"),
    });
    return (
        <Formik
            initialValues={{
                firstName: "",
                lastName: "",
                email: "",
                password: "",
                confirmPassword: "",
                city: "",
                country: "",
                confirmEmail: ""
            }}
            validationSchema={validate}
            onSubmit={(values) => {
                console.log(values);
            }}
        >
            {(formik) => (
                <div>
                    <h1 className="my-4 font-weight-bold-display-4">Sign Up</h1>

                    <Form>
                        <TextField label="First Name" name="firstName" type="text" />
                        <TextField label="Last Name" name="lastName" type="text" />
                        <TextField label="Email" name="email" type="email" />
                        <TextField label="Password" name="password" type="password" />
                        <TextField
                            label="Confirm Password"
                            name="confirmPassword"
                            type="password"
                        />
                        <TextField label="City" name="city" type="text" />
                        <TextField label="Country" name="country" type="text" />
                        <TextField label="Confirm Email" name="confirmEmail" type="text" />
                        <button className="btn btn-primary mt-3" type="submit">
                            Register
                        </button>
                        <button className="btn btn-danger mt-3 ml-3" type="reset">
                            reset
                        </button>
                    </Form>
                </div>
            )}
        </Formik>
    );
}

export default SignUp;