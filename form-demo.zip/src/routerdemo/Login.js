import React from 'react';

function Login(props) {
    return (
        <div>
          Welcome to Login Page
        </div>
    );
}

export default Login;
