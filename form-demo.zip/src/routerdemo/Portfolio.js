import React from 'react';

function Portfolio(props) {
    return (
        <div>
          Welcome to Portfolio Page
        </div>
    );
}

export default Portfolio;
