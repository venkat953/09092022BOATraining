import { BrowserRouter, Route, Switch } from 'react-router-dom'
import Login from './Login'
import Register from './Register'
import UserDetails from './UserDetails'
import PageNotFound from './PageNotFound';
import Header from './Header';
import LandingPage from './LandingPage';

function Routes(){
    return(
    <BrowserRouter>
    <div>
        <Header/>
        <Switch>
        <Route path="/" component={LandingPage} exact={true}/>
        <Route path="/register" component={Register}/>
        <Route path="/ud" component={UserDetails}/>
        <Route component={PageNotFound}/>
        </Switch>
    </div>
    
    
    </BrowserRouter>
    )
        
}
export default Routes