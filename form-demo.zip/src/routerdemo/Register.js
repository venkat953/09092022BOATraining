
import React from 'react';

function Register(props) {
    return (
        <div>
           welcome to register
        </div>
    );
}

export default Register;