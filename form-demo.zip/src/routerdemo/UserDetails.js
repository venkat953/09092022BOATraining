import React from 'react';

function UserDetails(props) {
    return (
        <div>
          Welcome to UserDetails Page
        </div>
    );
}

export default UserDetails;
