import React from 'react';
import {BrowserRouter,NavLink,Route,Switch } from 'react-router-dom'
import Login from './Login'
import Register from './Register'
import UserDetails from './UserDetails'
import Portfolio from './Portfolio'
import PageNotFound from './PageNotFound'


function LandingPage(props) {
    return (
        <div>
          Landing Page
        </div>
    );
}

export default LandingPage;
