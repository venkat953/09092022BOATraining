import { NavLink } from "react-router-dom"

const Header=()=>{
    return (
        <div>
            <NavLink to="/" exact={true}> LandingPage </NavLink>
            <div>
                <NavLink to="register"> Registration </NavLink></div>
            <div>
                <NavLink to="ud"> UserDetails </NavLink></div>
        </div>
        
    )
}

export default Header