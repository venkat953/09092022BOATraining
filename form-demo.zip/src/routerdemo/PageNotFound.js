import React from 'react';

function PageNotFound(props) {
    return (
        <div>
          oops PageNotFound 
        </div>
    );
}

export default PageNotFound;
