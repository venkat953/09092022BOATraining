import logo from './logo.svg';
import './App.css';
import { Switch, BrowserRouter, Route } from 'react-router-dom'
import ProductListing from './components/ProductListing'
import ProductDetail from './components/ProductDetail'
import Header from './components/Header';



function App() {
  return (
    <div>
      <Header />
      <BrowserRouter>
        <Switch>
          <Route path='/' component={ProductListing} exact={true} />
          <Route path='/product/:id' component={ProductDetail}/>
          <Route>404 Not Found</Route>
        </Switch>

      </BrowserRouter>


    </div>
  );
}

export default App;
