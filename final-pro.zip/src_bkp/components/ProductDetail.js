import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import axios from 'axios';
import { selectedProduct } from '../redux/actions/productActions';
//import { useParams } from 'react-router-dom'
function ProductDetail(props) {

    const product = useSelector((state) => state.product)
    const { title, image, price, category,description } = product;
    const productId = props.match.params.id
    const dispatch = useDispatch()
    console.log(product);


    const fetchProductDetail = async () => {
        const response = await axios.get(`https://fakestoreapi.com/products/${productId}`)
            .catch((err) => {
                console.log(err)
            })
        dispatch(selectedProduct(response.data))
    }
    useEffect(() => {
        fetchProductDetail()
    }, [productId])

    return (
        <div>
            ProductDetail
            <h3>{title}</h3>
            <div className="image">
                                <img src={image} alt={title} />
                            </div>
            <h3>₹{price}</h3>
            <h3>{category}</h3>
            <h3>{description}</h3>
        </div>
    );
}

export default ProductDetail;