import React from "react";
import App from "./App";
import Account from "./Account";
import { mount } from 'enzyme';

it('renders correctly', () => {
    const wrapper = mount(<App />)
    expect(wrapper.state('error')).toEqual(null)
})
it('testing header data', () => {
    const wrapper = mount(<App />)
    const header = <h1>Display Active User Account</h1>
    expect(wrapper.contains(header)).toBe(true)
})

const user = {
    name: 'Andrew',
    email: 'andrew@mail.com',
    username: 'Dave'
}

describe("testing all togather", () =>{
    it('accept user account details', () => {
        const wrapper = mount(<Account user={user} />)
        expect(wrapper.props().user).toEqual(user)
    })
    it('check the email detail',()=>{
        const wrapper=mount(<Account user={user}/>)
        const value=wrapper.find('p').text()
        expect(value).toEqual('andrew@mail.com')
    })
    it('testing loading data', () => {
        const wrapper = mount(<App />)
        const loading = <h3>Loading data.......</h3>
        expect(wrapper.contains(loading)).toBe(true)
    })
})