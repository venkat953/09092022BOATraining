



const Footer= (props)=> {
        return (
            <div>
                <p> {props.fdata}</p>
            </div>
        );
    }

    export default Footer