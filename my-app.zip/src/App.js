import logo from './logo.svg';
import './App.css';
import MainApp from './components/MainApp';
import AxiosApp from './axiosdemo/AxiosApp';
import MyReports from './HOC/ReportGenerator';
import OrderComponent from './lsu/OrderComponent';
import HookDemo from './hooks/HookDemo';
import UserApp from './hooks/UserApp';
import ContextApp from './HOC/ContextApp';

function App() {
  return (
    <div className="container">
      <p>welcome</p>
    
      
      
    <ContextApp/>
    </div>
  );
}

export default App;
