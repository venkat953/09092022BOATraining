import React, {useEffect, useState} from 'react';

function HookDemo(props){
    const [counter,setCounter]=useState(0)

    useEffect(()=>{
        console.log('called everytime')
    },[])
    useEffect(()=>{
        console.log('called everytime')
    },[counter])
    return (
        <div>
            <p> The couner is :{counter}</p>
            <button onClick={()=>setCounter(counter+1)}>increment</button>
            <button onClick={()=>setCounter(counter-1)}>decrement</button>
            <button onClick={()=>setCounter(0)}>reset</button>

        </div>
    )
}

export default HookDemo;