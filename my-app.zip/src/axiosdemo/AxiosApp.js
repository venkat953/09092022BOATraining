import { Component } from "react";
import axios from "axios";

const API_URL = "https://jsonplaceholder.typicode.com/users";

export default class AxiosApp extends Component {
  state = {
    users: [],
  };

  componentDidMount() {
    axios
      .get(API_URL)
      .then((response) => response.data)
      .then((data) => {
        //console.log(data);
        this.setState({users:data})
      });
  }
  render() {
      return <div class="container">
          <div class="col-xs-8">
              <h1>User Details</h1>
              {this.state.users.map((user) => (
                  <div class="card">
                      <div class="card-body">
                          <h5 classname="card-title">{user.username}</h5>
                          <h6 classname="card-subtitle">{user.email}</h6>
                      </div>
                  </div>
              ))}
          </div>
      </div>;
  }
}