import { Component } from "react";

export default class OrderComponent extends Component {
    state = {
        quantity: '',
        address: '',
        productname:''
    };
    orderInfoChanged = (val) => {
        this.setState({
            quantity: val
        })
    }
    addressChanged = (val) => {
        this.setState({
            address: val
        })
    }
    productnamechanged=(val)=>{
        this.setState({
            productname:val
        })
    }
    render() {
        return (
            <div>
                <h1>Welcome to Product Order Screen</h1>
                <ProductInfo quantity={this.state.quantity} oqc={this.orderInfoChanged} opnc={this.productnamechanged} />
                <Address address={this.state.address} oac={this.addressChanged} />
                <Summary quantity={this.state.quantity} oqc={this.orderInfoChanged} address={this.state.address} oac={this.addressChanged} productname={this.state.productname}/>
            </div>
        );
    }
}
class ProductInfo extends Component {
    handleChange = (e) => {
        this.props.oqc(e.target.value)
    }
    handleChange2 = (e) => {
        this.props.opnc(e.target.value)
    }
    render() {
        return (
            <div style={{ border: "3px solid red" }}>
                <h1>Product Information</h1>
                <p>
                    Product Name
                    <select onChange={this.handleChange2}>
                        <option value="Product-1">Product-1</option>
                        <option value="Product-2">Product-2</option>
                        <option value="Product-3">Product-3</option>
                    </select>
                </p>
                <p>
                    Enter Quantity: <input type="text"
                        value={this.props.quantity}
                        onChange={this.handleChange} />
                </p>
            </div>
        );
    }
}

class Address extends Component {
    handleChange = (e) => {
        this.props.oac(e.target.value)
    }
    render() {
        return (
            <div style={{ border: "3px solid red" }}>
                <h1>Address Information</h1>

                <p>
                    Address: <textarea value={this.props.address} onChange={this.handleChange}></textarea>
                </p>
            </div>
        );
    }
}

class Summary extends Component {
    handleChange = (e) => {
        this.props.oqc(e.target.value)
    }
    handleChange = (e) => {
        this.props.oac(e.target.value)
    }
    
    render() {
        return (
            <div style={{ border: "3px solid red" }}>
                <h1>Order Summary</h1>
                <p>Product Name :{this.props.productname}</p>
                <p>
                    <p>
                        Product Quantity:
                        <input type="text"
                            value={this.props.quantity}
                            onChange={this.handleChange} />
                    </p>
                </p>
                <p>Address:<textarea value={this.props.address} onChange={this.handleChange}></textarea>
                </p>
            </div>
        );
    }
}
