import { Component } from "react";

function reportHOC(inputComponent, inputData) {
  return class extends Component {
    state = {
      data: [],
      //columns: inputData.columns,
      header: inputData.header,
    };

    componentDidMount() {
      fetch(inputData.url)
        .then((res) => res.json())
        .then((result) => {
          this.setState({
            data: result,
          });
        });
    }
    render() {
      return <Data data={this.state} />;
    }
  };
}

class Data extends Component {
    render() {
        return (
            <div>
                <h2>{this.props.data.header}</h2>
                <div className="container">
                    <div className="col-xs-8">
                        {this.props.data.data.map((user) => (
                            <div className="card">
                                <div className="card-body">
                                    <h5 className="card-title">{user.username}</h5>
                                    <h6 className="card-subtitle">{user.email}</h6>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        );
    }
}

class Report extends Component {
  render() {
    return <div></div>;
  }
}
const EmployeeReport = reportHOC(Report, {
  url: "https://jsonplaceholder.typicode.com/users",
  header: " Employee Report",
});
const DepartmentReport = reportHOC(Report, {
  url: "https://jsonplaceholder.typicode.com/users",
  header: " Department Report",
});

export default class MyReports extends Component {
  render() {
    return (
      <div>
        <EmployeeReport />
        <DepartmentReport />
      </div>
    );
  }
}





/*
--------------------------------



class Data extends React.Component{

  
  render(){

    return (

    <div>

        <h2>{this.props.data.header}...</h2>

        <table>

          <thead>

            <tr>

            {this.props.data.columns.map(c => (

              <th>{c}</th>

            ))}

            </tr>

          </thead>

          <tbody>

          {this.props.data.data.map(emp => (

            <tr key={emp.Id}>

              {this.props.data.columns.map(c => (

              <td>{emp[c]}</td>

            ))}

              </tr>

          ))}

          </tbody>

        </table>

      </div>

    );

  }

}
*/