
import React, {useState,createContext,useContext} from 'react';


const  AppContext=createContext()
export default function ContextApp(props) {
    const [employee, setEmployee]=useState({id:101,Name:'Admin',city:'chennai',salary:12345})
    return (
        <div>
            <AppContext.Provider value={employee}>
            <Employee/>
            </AppContext.Provider>
        </div>
    );
}
function Employee(props) {
    let empContext=useContext(AppContext)
    return (
        <div>
            Employee Name:{empContext.Name}
            <br/>
            Employee Location:{empContext.city}
            <Salary/>
        </div>
    );
}

function Salary(props) {
    let salaryContext=useContext(AppContext)
    return (
        <div>
            Salary :{salaryContext.salary}
        </div>
    );
}

 